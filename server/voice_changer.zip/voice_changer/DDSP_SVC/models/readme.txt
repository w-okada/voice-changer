modules in this folder from https://github.com/yxlllc/DDSP-SVC at a1f4680ebf89c389b5085757184a8ef972c18009
